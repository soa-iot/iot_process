	layui.use(['carousel', 'form'], function(){
			  var carousel = layui.carousel
			  ,form = layui.form;
			  
			  //常规轮播
			  carousel.render({
			    elem: '#test1'
			    ,arrow: 'always'
		  });
		 });  
		
		layui.use([ 'element', 'layer' ], function() {
			var element = layui.element;
			var layer = layui.layer;

		});