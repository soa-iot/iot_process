package cn.soa.service.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import cn.soa.service.inter.ProcessVariableSI;

@Service
public class ProcessVariableS implements ProcessVariableSI {

	@Override
	public Map<String, Object> addVarsStartProcess(Map<String, Object> bussinessData) {
		// TODO Auto-generated method stub
		return null;
	}

}
