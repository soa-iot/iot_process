package cn.soa.controller;

/**
 * @ClassName: ReportC
 * @Description: 问题评估业务控制层
 * @author zhugang
 * @date 2019年5月29日
 */
public class Estimate {
	
}
