package cn.soa.controller;

/**
 * @ClassName: ReportC
 * @Description: 维修分配 - 业务控制层
 * @author zhugang
 * @date 2019年5月29日
 */
public class ArrangeRepairC {
	
}
