package cn.soa.controller;

/**
 * @ClassName: ReportC
 * @Description: 净化分配 - 业务控制层
 * @author zhugang
 * @date 2019年5月29日
 */
public class ArrangePureC {
	
}
